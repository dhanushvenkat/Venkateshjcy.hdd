#Assignment-1
a= "Welcome to India"
print(a)
print("Assignment-1-Completed")
print("================================================================================")

#Assignment-2
b="Welcome to Chennai"
print(b)
b="Welcome to Delhi"
print(b)
print("Assignment-2-Completed")
print("================================================================================")

#Assignment-3
c="Ram"
print("Hello "+c+",","How are you?")
print("Assignment-3-Completed")
print("================================================================================")

#Assignment-4
d='Albert Einstein once said, “A person who never made a mistake never tried anything new.”'
print(d)
print("Assignment-4-Completed")
print("================================================================================")

#Assignment-5
famous_person = "Albert Einstein"
print(famous_person+' '+'once said, “A person who never made a mistake never tried anything new.”')
print("Assignment-5-Completed")
print("================================================================================")

#Assignment-6
add='Addition is'
sub ='Subtraction is'
Mul ='Multiplication is'
Div ='Division is'
print(add,5+3)
print(sub,16-8)
print(Mul,4*2)
print(Div,64//8)
print("Assignment-6-Completed")
print("================================================================================")

#Assignment-7
fav_num = 7
print("My Favourite number is:",fav_num)
print("Assignment-7-Completed")
print("================================================================================")

#Assignment-8
myname= "Venkatesh"
from datetime import date

today = date.today()
print("My Name is:", myname)
print("Today's date:", today)
print("This is a simple program that showing my name and current date, Current date will get from the date module ")
print("Assignment-8-Completed")
print("================================================================================")

#Assignment-9

names=['Ram','Rahul','Ravi','Dhanu','sundar','dhoni']
for i in range(len(names)):
    print(names[i])
print("Assignment-9-Completed")
print("================================================================================")

#Assignment-10
names=['Ram','Rahul','Ravi','Dhanu','sundar','dhoni']
for i in range(len(names)):
    print("Hi",names[i],",","How is going on?")
print("Assignment-10-Completed")
print("================================================================================")


#Assignment-11
cars=['Alto','Celerio','WagonR','Brezza','Ertiga']
for i in range(len(cars)):
    print("I would like to own a",cars[i],"Car")
print("Assignment-11-Completed")
print("================================================================================")



